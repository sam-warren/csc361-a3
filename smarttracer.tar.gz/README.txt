Sam Warren
V00889558
CSC361
April 4, 2021

Programming Assignment 3

Installation
Unzip smarttracer.tar.gz into your favourite directory

Running SmartTracer
Place trace files in the Traces directory and run them with: python3 SmartParser.py ./{your-file-name}.pcap

